package lab_pckg;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {

   public static void main(String[] arg) {
	   List<notesArchiver> notes= null;
      notesArchiver notesArchiver = null;
      notesArchiver required = null;
      String readCheck = "";
      try {

         ServerSocket socketConnection = new ServerSocket(11111);

         System.out.println("Server Waiting");

         Socket pipe = socketConnection.accept();

         
         ObjectInputStream serverInputStream = new    
            ObjectInputStream(pipe.getInputStream());

         ObjectOutputStream serverOutputStream = new 
         ObjectOutputStream(pipe.getOutputStream());

         notesArchiver = (notesArchiver )serverInputStream.readObject();
         
         readCheck = notesArchiver.getnotesArchiverName();
         
         if(notesArchiver.getchoice()=="write"){
         //serialized object
         try
         {
            FileOutputStream fileOut =
            new FileOutputStream("C:/notes.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(notesArchiver);
            out.close();
            fileOut.close();
            System.out.printf("Serialized data is saved in C:/notes.ser");
         }catch(IOException i)
         {
             i.printStackTrace();
         }
         
         
         }
         
         //deserialized all objects
         
         else{
         
         try {
             ObjectInputStream in = new ObjectInputStream(new FileInputStream("C:/notes.ser"));
             notes = (List<notesArchiver>) in.readObject(); 
             in.close();
         }
         catch(Exception e) {}
         
         //storing data in map for check
         Map m1 = new HashMap(); 
         m1.put(notesArchiver.getdata(), notesArchiver.getnotesArchiverName());
         System.out.println(m1);
         
         for (int i = 0; i < notes.size(); i++) {
 		     notesArchiver temp = notes.get(i);
 		    
 		     if(temp.getnotesArchiverName()==readCheck){
 		    	 required = temp;
 		    	 
 		 }
 		
 		}
         
         notesArchiver .setdata(required.getdata());
         notesArchiver .setnotesArchiverName(required.getnotesArchiverName());
         notesArchiver.setchoice(required.getchoice());
         serverOutputStream.writeObject(notesArchiver);
         }
         
         serverInputStream.close();
         serverOutputStream.close();


      }  catch(Exception e) {System.out.println(e); 
      }
   }

}