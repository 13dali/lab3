package lab_pckg;

import junit.framework.TestCase;

import static org.junit.Assert.*;

public class Test {

	@org.junit.Test
	public void test() {
		Client cl = new Client();
		notesArchiver notes = null;
	
		String expectedUserName = "tony";
		String expectedData = "My Name is tony";
		
		String expectedUserName2 = "tony2";
		String expectedData2 = "My Name is tony2";
		
	 
		notes = cl.clientCode("My Name is tony", "tony", "write");
		
		notes = cl.clientCode("My Name is tony", "tony", "read");
		
		//positive test
		assertEquals(expectedUserName,notes.getnotesArchiverName());
		assertEquals(expectedData, notes.getdata());
		
		// negative test
		
		assertNotEquals(expectedUserName2,notes.getnotesArchiverName());
		assertNotEquals(expectedData2, notes.getdata());
		
		//check for the null value of the returned object of the class
		
		assertNull(notes);

	}

}
