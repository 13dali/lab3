package lab_pckg;

import java.io.*;
import java.util.*;

public class notesArchiver implements Serializable {

   private String data;
   private String notesArchiverName;
   private String choice;

   notesArchiver(String data, String name, String choice ) {
      this.data = data;
      notesArchiverName= name;
      this.choice = choice; 
   }

    public String getdata() {
      return this.data ;
   }

   public void setdata(String data) {
     this.data = data;
   }

   public String getnotesArchiverName() {
      return notesArchiverName ;
   }

   public void setnotesArchiverName(String name) {
      notesArchiverName = name;
   }
   
   public String getchoice() {
	      return this.choice ;
	   }

	   public void setchoice(String data) {
	     this.choice = data;
	   }
}
