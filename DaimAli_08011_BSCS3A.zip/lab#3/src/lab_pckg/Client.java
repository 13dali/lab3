package lab_pckg;

import java.io.*;
import java.net.*;
import java.util.Scanner;


public class Client {
	
	public static notesArchiver clientCode(String data, String username, String choice){
		 
		notesArchiver User = new notesArchiver(data, username, choice);
		
		try {
		

         System.out.println("notesArchiverData= "
                            + User .getdata());
         System.out.println("notesArchiverName= "
                            + User .getnotesArchiverName());

         Socket socketConnection = new Socket("127.0.0.1", 11111);


         ObjectOutputStream clientOutputStream = new
            ObjectOutputStream(socketConnection.getOutputStream());
         ObjectInputStream clientInputStream = new 
            ObjectInputStream(socketConnection.getInputStream());

         clientOutputStream.writeObject(User);

         User= (notesArchiver)clientInputStream.readObject();

         System.out.println("notesArchiverdata= "
                            + User .getdata());
         System.out.println("notesArchiverName= "
                            + User .getnotesArchiverName());

         clientOutputStream.close();
         clientInputStream.close();

      } catch (Exception e) {
    	  
    	  System.out.println(e);
    	  
      }
		
		
		return User; 
	}

   public static void main(String[] arg) {
	   
    
    	  
    	  String data = "";
    	  Scanner reader = new Scanner(System.in);  // Reading from System.in
    	  System.out.println("Enter your name: ");
    	  String username = reader.next();
    	  System.out.println("Enter your data: ");
    	  data = reader.next();
    	  System.out.println("What do you want read or write: ");
    	  String choice = reader.next();
    	  
    	  
    	  notesArchiver s = clientCode(data, username, choice);
        
   }